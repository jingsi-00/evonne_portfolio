   // Create stars background
        function createStars() {
            const stars = document.getElementById('stars');
            const count = 200;
            
            for (let i = 0; i < count; i++) {
                const star = document.createElement('div');
                const size = Math.random() * 2;
                
                star.style.position = 'absolute';
                star.style.width = `${size}px`;
                star.style.height = `${size}px`;
                star.style.borderRadius = '50%';
                star.style.backgroundColor = i % 20 === 0 ? '#c8a2c8' : '#fff';
                star.style.top = `${Math.random() * 100}%`;
                star.style.left = `${Math.random() * 100}%`;
                star.style.opacity = Math.random();
                star.style.animation = `twinkle ${Math.random() * 5 + 3}s infinite alternate`;
                
                stars.appendChild(star);
            }
        }      

 